package com.boky.PFE.service;

import com.boky.PFE.entite.SousAdmin;

import java.util.List;
import java.util.Optional;

public interface AdminService
{
    SousAdmin AjouterAdmin(SousAdmin admin);
    SousAdmin ModifierAdmin(SousAdmin admin);
    List<SousAdmin> AfficherAdmin();
    void SupprimerAdmin (Long id);
    Optional<SousAdmin> getAdminById(Long id);
}
