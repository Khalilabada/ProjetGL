package com.boky.PFE.repository;

import com.boky.PFE.entite.SousAdmin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminRepository extends JpaRepository<SousAdmin,Long>
{

    boolean existsByEmail(String email);

    SousAdmin findAdminByEmail(String email);
}
